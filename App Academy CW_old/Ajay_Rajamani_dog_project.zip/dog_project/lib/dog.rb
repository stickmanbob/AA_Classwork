
class Dog
    def initialize ( name, breed, age, bark, fav_foods)
        @name = name
        @breed = breed
        @age = age
        @bark = bark
        @favorite_foods = fav_foods
    end
    
    def name
        @name
    end

    def breed
        @breed
    end

    def age
        @age
    end

    def age= (n)
        @age = n 
    end
   
    def bark 
        
        return @bark.upcase if @age > 3
        @bark.downcase if @age <=3
    end 

    def favorite_foods
        @favorite_foods
    end

    def favorite_food?(food)
        food = food.downcase
        
        favorite_foods.each {|fav| 
        fav = fav.downcase
        return true if fav == food
        }
        false
    end


end

