def my_map(arr,&block)
    mapped = []

    arr.each do |ele|
        
        mapped << block.call(ele)

    end
    mapped
end

def my_select(arr,&block)
    selection  = []
    arr.each {|ele|
        
        if block.call(ele)
            selection << ele
        end
}

selection
end

def my_count(arr,&block)

    count = 0

    arr.each {|ele|

        if block.call(ele)
            count+=1
        end
    }
    count
end

def my_any?(arr, &cond)
    arr.each{|ele|

      return true  if cond.call(ele)
            
        
    }
    false
end

def my_all?(arr,&cond)
    arr.each {|ele|

       return false if !cond.call(ele)

            
        
    }
    true
end

def my_none?(arr,&cond)

    arr.each {|ele|

        return false if cond.call(ele)
    }
    true 

end