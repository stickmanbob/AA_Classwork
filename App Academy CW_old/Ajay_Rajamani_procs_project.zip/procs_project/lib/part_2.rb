def reverser(str,&block)

    rev = str.reverse

    block.call(rev)

end

def word_changer (sent,&block)

    words = sent.split(" ")

    words.map! {|word| block.call(word)}

    words.join(" ")
end

def greater_proc_value(n, proc1, proc2)

   value1 = proc1.call(n)
   value2 = proc2.call(n)

   [value1, value2].max

end

def and_selector (arr, proc1, proc2)
  
    arr.select {|ele| proc1.call(ele) && proc2.call(ele)}

end

def alternating_mapper(arr, p1, p2)

    arr.map.with_index {|ele,i| 

        if i.even?
            p1.call(ele)
        else
            p2.call(ele)
        end
    }

end