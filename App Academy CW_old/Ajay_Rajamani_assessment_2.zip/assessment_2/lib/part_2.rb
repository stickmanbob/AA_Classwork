def proper_factors(n)
    factors = []
    (1...n).each {|factor| factors << factor if n%factor == 0}
    factors
end

def aliquot_sum(n)
    proper_factors(n).sum
end

def perfect_number?(n)
    return true if n == aliquot_sum(n)
    false
end

def ideal_numbers (n)
    ideal_nums = []
    i = 1
    while ideal_nums.length < n
        ideal_nums << i  if perfect_number?(i)
        i+=1
    end
    ideal_nums 
end