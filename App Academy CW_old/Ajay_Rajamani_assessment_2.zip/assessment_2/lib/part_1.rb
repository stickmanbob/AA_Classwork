def my_reject(arr,&block)
    arr.select {|ele| !block.call(ele)}
end

def my_one?(arr,&block)
    count = 0
    arr.each {|ele| count +=1 if block.call(ele)}
    return true if count == 1
    false 
end

def hash_select (hash,&block)
    newhash = {} 
    hash.each {|k,v|

       newhash[k] = v if block.call(k,v) 
    
    }
    newhash 
end

def xor_select(arr, p1, p2)
    arr.select {|ele| p1.call(ele) && !p2.call(ele) || p2.call(ele) && !p1.call(ele)}
end

def proc_count(n,procs)
    count = 0
    procs.each {|proc| count +=1 if proc.call(n)}
    count 
end