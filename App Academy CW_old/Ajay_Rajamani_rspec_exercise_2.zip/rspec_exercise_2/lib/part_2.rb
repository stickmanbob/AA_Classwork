def palindrome?(word)
    i = -1

    while i > -word.length
        if word[i] != word[-i - 1]
            return false
        end
        i-=1
    end
true
end

def substrings(str)
    outer = 0
    subs = []
    while outer < str.length
        i = 0
        while i< str.length

            if i>=outer
            
                subs << str[outer..i]

            end
            i+=1
        end
        outer+=1
    end
    return subs
end

def palindrome_substrings(str)
    subs = substrings(str)

    subs.select!{|word| palindrome?(word) && word.length>1}

end
