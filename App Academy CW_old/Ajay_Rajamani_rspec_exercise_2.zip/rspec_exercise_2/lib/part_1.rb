def partition(arr,n)
    twodarr = [[],[]]
    arr.each do |ele|

        if ele <n
            twodarr[0] << ele
        else
            twodarr[1] << ele
        end

    end
    return twodarr
end

def merge(hash1,hash2)
    newhash = {}
    hash1.each do |k,v|
        newhash[k] = v
    end

    hash2.each do |k,v|

        newhash[k] = v
        
    end
    return newhash
end

def censor(sent,beeps)

    words = sent.split
    words.each_with_index do |word,i|
    beeps = beeps.map{|swear| swear.downcase}
        if beeps.include?(word.downcase)
            
            words[i] = vowel_replace(word)

        end

    end
    return words.join(" ")
end

def vowel_replace(word)

    vowels = "aeiouAEIOU"
    word.each_char.with_index do |c,i|
        if vowels.include?(c)
            word[i] = "*"
        end
    end

    return word

end

def power_of_two?(x)
    if Math.log(x,2)%1 == 0
        return true
    else
        return false
    end
end