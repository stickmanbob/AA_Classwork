def element_count(arr)
    hash = Hash.new(0)

    arr.each do |ele|
        hash[ele] +=1
    end
    return hash
end

def char_replace!(str,hash)

    i = 0
    while i < str.length
        char = str[i]
        if hash.include?(char)
            str[i] = hash[char]
        end
        i+=1
    end
    return str 
end

def product_inject(arr)
    arr.inject {|prod,ele| prod*ele}
end