def is_prime?(x)
    return false if x < 2
    (2...x).each do |factor|

        if x % factor == 0
            return false
        end

    end
    true
end

def nth_prime(n)
    if n < 1
        return "invalid input"
    end
    primes = []
    i = 2
    while primes.length < n
        if is_prime?(i)

            primes << i
        end
        i+=1
    end
    return primes[-1]
end

def prime_range(min,max)
    primes = []
    (min..max).each do |num|
        if is_prime?(num)

            primes << num
        end
    end
    return primes 
end