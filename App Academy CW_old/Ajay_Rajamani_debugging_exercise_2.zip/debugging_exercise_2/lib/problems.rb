# Run `bundle exec rspec` and satisy the specs.
# You should implement your methods in this file.
# Feel free to use the debugger when you get stuck.

def largest_prime_factor(x)
    x.downto(1).each do |i|
        if x % i == 0 and prime?(i)
            return i
        end
    end

end

def prime?(num)
    return false if num < 2

    (2...num).each do |factor|
        if num % factor == 0
            return false
        end
    end
    return true
end

def unique_chars?(str)

    count = Hash.new(0)

    str.each_char do |char|
        count[char] +=1
    end

    count.each {|k,v| return false if v >1}

    true

end

def dupe_indices(arr)
    dupeindexhash = {}
   count = Hash.new(0)
    dupes = []
   arr.each do |ele|

      count[ele] +=1

   end

   count.each {|k,v| dupes << k if v>1}

   dupes.each do |key|
        indexes = []
        arr.each_with_index do |ele,i|

            if key == ele
                indexes << i
            end

        end
        dupeindexhash[key] = indexes

   end
   return dupeindexhash

end

def ana_array(arr1,arr2)
    count1 = array_count(arr1)
    count2 = array_count(arr2)

    return count1 == count2
end

def array_count(arr)

    count = Hash.new(0)

    arr.each {|ele| count[ele] +=1 }

    return count
end

