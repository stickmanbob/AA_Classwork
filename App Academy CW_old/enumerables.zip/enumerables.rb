class Array
    def my_each(&prc)
        i = 0
        while i < self.length
            prc.call(self[i])
            i += 1
        end
        self
    end  
    # return_value = [1, 2, 3].my_each do |num|
    #   puts num
    # end.my_each do |num|
    #   puts num
    # end
    # # => 1
    #      2
    #      3
    #      1
    #      2
    #      3

    # p return_value  # => [1, 2, 3]

    def my_select(&prc)
        res = []
        self.my_each do |ele|
            res << ele if prc.call(ele)
        end
        res
    end
    # a = [1, 2, 3]
    # p a.my_select { |num| num > 1 } # => [2, 3]
    # p a.my_select { |num| num == 4 } # => []

    def my_reject(&prc)
        res = []
        self.my_each do |ele|
            res << ele if !prc.call(ele)
        end
        res
    end

    # a = [1, 2, 3]
    # p a.my_reject { |num| num > 1 } # => [1]
    # p a.my_reject { |num| num == 4 } # => [1, 2, 3]

    def my_any?(&prc)
        self.each do |ele|
            return true if prc.call(ele) 
        end
        false
    end

    def my_all?(&prc)
        self.each do |ele|
            return false if !prc.call(ele) 
        end
        true
    end

    # a = [1, 2, 3]
    # p a.my_any? { |num| num > 1 } # => true
    # p a.my_any? { |num| num == 4 } # => false
    # p a.my_all? { |num| num > 1 } # => false
    # p a.my_all? { |num| num < 4 } # => true

    def my_flatten
        res = []        
        self.each do |ele|
            if ele.kind_of?(Array) 
                res += ele.my_flatten 
            else
                res << ele
            end 

        end
        return res 
    end

    # p [1, 2, 3, [4, [5, 6]], [[[7]], 8]].my_flatten # => [1, 2, 3, 4, 5, 6, 7, 8]

    def my_zip(*args)
        
        self.map.with_index do |ele, i|
            others = []
            args.each do |subArr|
                others << subArr[i]
            end
            [ele] + others
        end
    end
    
    
    #     a = [ 4, 5, 6 ]
    # b = [ 7, 8, 9 ]
    # p [1, 2, 3].my_zip(a, b) # => [[1, 4, 7], [2, 5, 8], [3, 6, 9]]
    # p a.my_zip([1,2], [8])   # => [[4, 1, 8], [5, 2, nil], [6, nil, nil]]
    # p [1, 2].my_zip(a, b)    # => [[1, 4, 7], [2, 5, 8]]

    # c = [10, 11, 12]
    # d = [13, 14, 15]
    # [1, 2].my_zip(a, b, c, d)    # => [[1, 4, 7, 10, 13], [2, 5, 8, 11, 14]]

    def my_rotate(rotation = 1)

        indices = []
        self.each_index do |i|
            indices << i
        end

        new_indices = indices.map {|index| (index + rotation) % (self.length)}

        self.map.with_index do |ele,i|
            ele = self[new_indices[i]]
        end
       
    end
     # if rotation > 0
        #     rotation.times {self.push(self.shift)}
        # else 
        #     -rotation.times {self.unshift(self.pop)}
        # end
        # self
        a = [ "a", "b", "c", "d" ]
# p a.my_rotate         #=> ["b", "c", "d", "a"]
# p a.my_rotate(2)      #=> ["c", "d", "a", "b"]
# p a.my_rotate(-3)     #=> ["b", "c", "d", "a"]
# p a.my_rotate(15)     #=> ["d", "a", "b", "c"]

    def my_join(separator = "")
        
        result  = ""
        self.each_with_index do |ele, i|
            if i == 0
                result += ele
            else
                result += separator + ele 
            end
        end
        result 
    end

    # a = [ "a", "b", "c", "d" ]
    # p a.my_join         # => "abcd"
    # p a.my_join("$")    # => "a$b$c$d"

    def my_reverse
        res= []
        i = -1
        while i >= -self.length
            res << self[i]
            i -= 1
        end
        res
    end
    # p [ "a", "b", "c" ].my_reverse   #=> ["c", "b", "a"]
    # p [ 1 ].my_reverse               #=> [1]

end

def factors(num)
    res = []
    (1..num).each do |i|
        res << i if num % i == 0
    end
    res
end

# p factors(5)

# p factors(24)


class Array
  def bubble_sort!(&prc)
    prc ||= Proc.new {|num1, num2| num1 <=> num2}
    sorted = false
    while !sorted
        sorted = true
        i = 0
        while i < self.length - 1
            num1 = self[i]
            num2 = self[i+1]
            if prc.call(num1,num2) > 0
                self[i],self[i+1] = self[i+1],self[i]
                sorted = false 
            end
            i+=1
        end
        
    end
    self 
  end

  def bubble_sort(&prc)
    result = []
    self.each {|ele| result << ele}
    prc ||= Proc.new {|num1, num2| num1 <=> num2}
    sorted = false
    while !sorted
        sorted = true
        i = 0
        while i < result.length - 1
            num1 = result[i]
            num2 = result[i+1]
            if prc.call(num1,num2) > 0
                result[i],result[i+1] = result[i+1],result[i]
                sorted = false 
            end
            i+=1
        end
        
    end
    result
  end

end

def substrings(str)
    res = []
    (0...str.length).each do |i|
        (i...str.length).each do |j|
            res << str[i..j]
        end
    end
    res 
end

def subwords(word,dictionary)
    
    substrings(word).select {|word| dictionary.include?(word)}

end

dictionary = ["at", "a"]

p subwords("cat",dictionary)