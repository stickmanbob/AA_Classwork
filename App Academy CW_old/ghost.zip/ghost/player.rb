class Player

    def initialize 
        
    end
end