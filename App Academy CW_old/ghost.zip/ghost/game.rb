class Game
    attr_reader :current_player

    def initialize
        @dictionary = Set[]
        words = File.open('./dictionary.txt')
        words.each do |line|
            @dictionary << line 
        end
        @player1 = :X
        @player2 = :O
        @fragment = "" 
        @current_player = @player1 
        @game_over = false
    end

    def previous_player 
        @current_player == @player1 ? @player2 : @player1      
    end

    def next_player!
        @current_player = @current_player == @player1 ?  @player2 : @player1
    end


    def valid_play?(char)
        alpha = ("a".."z").to_a
        return false if !alpha.include?(char)
        test = @fragment + char
        @dictionary.each {|word| return true if word[0...test.length] == test}
        false
    end


    def take_turn(player)
        valid = false
        until valid
            puts "#{player} Enter a letter"
            guess = gets.chomp
            if valid_play?(guess)
                valid = true
            end
        end

        @fragment += guess
        if @dictionary.include?(@fragement) 
            puts "#{previous_player} loses!"
            @game_over = true
            
        end

    end

    def play_round
        
        while !@game_over
            take_turn(@current_player)
            next_player! 
        end

    end
end


