def all_words_capitalized?(array)
    array.all? { |word| word_caps?(word)}

end

def word_caps?(word)

    word.each_char.with_index do |c,i|
        return false if i==0 && c.upcase != c
        return false if i > 0 and c.downcase != c
    end
    true
end

def no_valid_url?(urls)

    urls.none?{|url| valid_url?(url)}
    
end

def valid_url?(url)

    valid_url_ext = ['com', 'net', 'io','org']

    parts = url.split(".")

    parts.each {|part| return true if valid_url_ext.include?(part)}
    false
end

def any_passing_students?(students)

    students.any?{|student| avg_array(student[:grades]) >=75}

end

def avg_array(array)

    return array.sum/array.length.to_f
end