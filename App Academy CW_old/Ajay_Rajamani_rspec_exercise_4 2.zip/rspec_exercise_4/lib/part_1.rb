def my_reject(array, &block)
    new_arr = []
    array.each{ |ele|
        if !block.call(ele)
            new_arr << ele
        end
    }
    new_arr
end

def my_one?(array, &block)
    count = 0 
    array.each do |ele|
       if block.call(ele)
            count += 1
       end
    end
count == 1
end

def hash_select (hash,&block)
    selected = {}
    hash.each do |k,v|
        if block.call(k,v)
            selected[k] = v 
        end
    end
    return selected 
end

def xor_select(arr, prc1, prc2)
    new_array = []

    arr.each do |ele|
        if (prc1.call(ele) && !prc2.call(ele)) || (prc2.call(ele) && !prc1.call(ele))
            new_array << ele
        end
    end
new_array
end

def proc_count(val,array)
    count = 0
    array.each do |proc|
       if proc.call(val)
            count +=1
       end
    end
    count
end