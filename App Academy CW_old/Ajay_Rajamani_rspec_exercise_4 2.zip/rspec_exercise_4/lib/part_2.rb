def proper_factors(num)
   factors = []
    (1...num).each do |n|
        if num%n == 0
            factors << n 
        end
    end
    factors
end

def aliquot_sum(num)
    proper_factors(num).sum

end

def perfect_number?(n)
    n == aliquot_sum(n)

end

def ideal_numbers(n)
    arr = []
    i = 1
    while arr.length < n
        if perfect_number?(i)
            arr << i
        end
        i += 1
    end
arr
end