def average(x,y)

    (x+y)/2.0


end

def average_array(arr)
    arr.sum.to_f/arr.length
end

def repeat(str,num)

    str*num

end

def yell(str)
    str.upcase + "!"
end

def alternating_case(str)

    arr = str.split

    arr.map!.with_index do |str,i|

        if i %2 == 0
            str.upcase
        else
            str.downcase
        end



    end
    return arr.join(" ")
end