def hipsterfy(word)
    vowels = "aeiouAEIOU"
    i = -1

    while i > word.length * -1

        if vowels.include?(word[i])
           word[i] = ""
           return word 
        end


        i-=1
    end

    return word
end

def vowel_counts(str)
    vowels = "aeiouAEIOU"
    hash = Hash.new(0)
    str.each_char do |c| #using c to represent each character
        if vowels.include?(c)
            hash[c.downcase]+=1
        end
    end
    return hash 
end

def caesar_cipher(mess,n)
    alpha = "abcdefghijklmnopqrstuvwxyz"
    ciphermess = ""
    mess.each_char do |c|
        if alpha.include?(c)
            idx = alpha.index(c)
            shift  = (idx+n)%26
            ciphermess += alpha[shift]
        else
            ciphermess += c
        end
    end
    return ciphermess 
end