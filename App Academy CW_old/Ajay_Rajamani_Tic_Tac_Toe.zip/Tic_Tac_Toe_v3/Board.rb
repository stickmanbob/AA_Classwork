class Board
    def initialize(size)
        @size = size
        @grid = Array.new(size) {Array.new(size,nil)}
        
    end

    def valid?(pos)
        pos.all? {|coordinate| coordinate < @size and coordinate >= 0}
    end

    def [](pos)
        y = pos[0]
        x = pos[1]
        return @grid [y][x]
    end

    def []=(pos,val)
        y = pos[0]
        x = pos[1]
        @grid[y][x] = val
    end

    def empty?(pos)
        return true if !self[pos]
        false
    end

    def place_mark(pos,mark)
        raise "invalid play!" if !empty?(pos) or !valid?(pos)
        self[pos] = mark 
    end

    def print_grid
        @grid.each do |row|
            row.each do |space|
                if !space 
                    print "."
                else 
                    print space
                end
            end
            print "\n"  
        end

    end


    def check_winner(mark)
        
        check_hor(mark) or check_vert(mark) or check_diagonals(mark)
    end

    def check_hor(mark)
        @grid.each do |row|
            return true if row.all? {|ele| ele == mark}
        end
        false
    end

    def check_vert(mark)
        columns = @grid.transpose
        columns.any? {|column| column.all?{|space| space == mark}}
    end




    def check_diagonals(mark)
        check_one_diagonal(@grid,mark) || check_one_diagonal(@grid.reverse,mark)
    end

  
    def check_one_diagonal(array,mark)
        i = 0
        prv_value = mark
        while i < array.length
            return false if array[i][i] != prv_value
            i += 1
        end
        true
    end

    def empty_positions?
        @grid.any? {|row|
            row.any? {|space| !space}
        }
    end

    def legal_positions
        legal_pos = []
        y = 0
        while y < @size
            x = 0
            while x < @size 
                legal_pos << [y,x] if empty?([y,x])
                x+=1
            end
            y+=1
        end
        legal_pos


    end





end

# test cases
# b = Board.new (5)
# b.place_mark([0,0],:X)
# b.place_mark([1,1],:X)
# b.place_mark([2,2],:X)
# b.place_mark([3,3],:X)
# b.place_mark([4,3],:X)
# b.print_grid
# p b.legal_positions
# p b.check_winner(:X) 