require_relative ("./Board.rb")
require_relative ("./human_player.rb")
require_relative ("./computer_player.rb")

class Game

    def initialize(size, player_options)
        
        @players = []
        
        player_options.each do |mark,is_computer|
            if is_computer
                @players << ComputerPlayer.new(mark)
            else
                @players << HumanPlayer.new(mark)
            end
        end

        @board = Board.new(size)
        
        @current_player = @players[0]

    end

    def switch_turn
        @players.rotate! 
        @current_player = @players[0]
    end

    def play 
        while @board.empty_positions?
            @board.print_grid
            pos = @current_player.get_position(@board.legal_positions)
            @board.place_mark(pos, @current_player.mark)
            if @board.check_winner(@current_player.mark)
                print "Player #{@current_player.mark} Won!"
                return 
            else
                switch_turn
            end
        end
        print "It's a Draw!"
    end

end

