class ComputerPlayer

    attr_reader :mark 
    
    def initialize(mark)
        @mark = mark
    end

    def get_position(legal_positions)
        pos = legal_positions.sample
        puts "Computer #{@mark} places at #{pos}"
        return pos 
    end



end

# # test cases
# legal_positions = [[1,1],[0,0],[1,2],[4,3]]
# comp = ComputerPlayer.new(:X)

# p comp.get_position(legal_positions)