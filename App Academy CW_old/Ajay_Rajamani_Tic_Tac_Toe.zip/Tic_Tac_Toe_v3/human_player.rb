class HumanPlayer

    attr_reader :mark 
    
    def initialize(mark)
        @mark = mark
    end

    def get_position(legal_positions)
        puts "Player #{@mark}, enter two numbers representing a position in the format `row col`"
        puts "(eg, '0 0', '1 2', '2 2')"
        input = gets.chomp
        pos = input.split(" ")
        pos.map! {|coordinate| coordinate.to_i}
        if !legal_positions.include?(pos)
            print "Invalid input!"
            return get_position(legal_positions)
        else
            return pos 
        end

    end



end

# #test cases

# positions = [[1,1],[0,0],[3,2],[5,4],[2,8]]

# test = HumanPlayer.new(:X)

# p test.get_position(positions)