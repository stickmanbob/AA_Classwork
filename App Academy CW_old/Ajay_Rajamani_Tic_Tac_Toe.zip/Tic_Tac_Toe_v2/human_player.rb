class HumanPlayer

    attr_reader :mark 
    
    def initialize(mark)
        @mark = mark
    end

    def get_position
        puts "Player #{@mark}, enter two numbers representing a position in the format `row col`"
        puts "(eg, '0 0', '1 2', '2 2')"
        input = gets.chomp
        pos = input.split(" ")
        raise "invalid input!" if pos.length != 2
        pos.map {|coordinate| coordinate.to_i}
    end



end